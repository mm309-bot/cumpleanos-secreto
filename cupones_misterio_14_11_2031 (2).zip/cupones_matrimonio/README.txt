CUpones románticos — paquete preparado

IMPORTANTE
Los QR incluidos apuntan a:
https://TU-USUARIO.github.io/TU-REPOSITORIO/?c=...

Antes de imprimirlos, necesitas publicar index.html en una dirección web real y reemplazar la URL base en los QR.

Lógica:
- 14 = DÍA -> revela 14 de noviembre de 2031 y palabra ALGÚN
- 31 = AÑO -> revela 2031 y palabra DÍA
- 11 = MES -> revela noviembre y palabra QUIERO
- Los otros 6 QR muestran directamente: QUE / SEAS / MI / ESPOSA / EN / 2031
- Al resolver los tres especiales, aparece CÁSATE CONMIGO + 14·11·2031.
- La web usa localStorage para recordar los tres especiales resueltos en ese teléfono.

Para publicar gratis:
1. Crea un repositorio público en GitHub.
2. Sube index.html.
3. Activa GitHub Pages.
4. Obtendrás una URL tipo https://TU-USUARIO.github.io/TU-REPOSITORIO/
5. Regenera los 9 QR con esa URL usando Canva o cualquier generador QR.
